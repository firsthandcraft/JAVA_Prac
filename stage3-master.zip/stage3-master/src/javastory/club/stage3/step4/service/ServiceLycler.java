package javastory.club.stage3.step4.service;

public interface ServiceLycler {
	//
	BoardService createBoardService();
	ClubService createClubService();
	MemberService createMemberService();
	PostingService createPostingService();
}