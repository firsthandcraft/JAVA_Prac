package javastory.club.stage3.step1.entity;

public interface AutoIdEntity {
	//
	String getId();
	String getIdFormat();
	void setAutoId(String autoId);
}