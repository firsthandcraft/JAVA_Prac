package javastory.club.stage3.step1.entity.club;

public enum AddressType {
	//
	Home, 
	Office
}