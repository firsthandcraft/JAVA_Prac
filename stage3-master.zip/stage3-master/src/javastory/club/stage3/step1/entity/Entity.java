package javastory.club.stage3.step1.entity;

public interface Entity {
	//
	String getId();
}