package javastory.club.stage2.step1.entity;

public enum RoleInClub {
	//
	Member, 
	President
}