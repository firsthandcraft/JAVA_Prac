package javastory.club.stage2.util;

public class InvalidArgumentException extends Exception {
	//
	private static final long serialVersionUID = 4156972833189035090L;

	public InvalidArgumentException(String message) {
		super(message); 
	}
}